import { CommonModule } from '@angular/common';
import { Component, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
  imports: [CommonModule] 
})
export class NavbarComponent {
  user: any = null; // Simulación, reemplazar con datos reales

  constructor(private router: Router, private cdr: ChangeDetectorRef) {console.log("Estado inicial de user:", this.user);}

  logout() {
    this.user = null;
    this.cdr.detectChanges(); // Forzar actualización de la vista
    this.router.navigate(['/auth/login']);
  }
}
