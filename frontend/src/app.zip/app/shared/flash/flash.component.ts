import { Component } from '@angular/core';

@Component({
  selector: 'app-flash',
  imports: [],
  templateUrl: './flash.component.html',
  styleUrl: './flash.component.css'
})
export class FlashComponent {

}
