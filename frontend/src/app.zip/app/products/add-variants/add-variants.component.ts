import { Component } from '@angular/core';

@Component({
  selector: 'app-add-variants',
  imports: [],
  templateUrl: './add-variants.component.html',
  styleUrl: './add-variants.component.css'
})
export class AddVariantsComponent {

}
